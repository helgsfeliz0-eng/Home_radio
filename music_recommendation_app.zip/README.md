# Your Music App (Classic Rock, Jazz & World)

A tiny, local-first web app that recommends artists similar to your favorites and gives quick-play links for each artist on YouTube or Spotify.

## Features
- Preloaded with your favorites: Genesis, The Beatles, The Rolling Stones, Eric Clapton, Nina Simone, Goran Project, Cesária Évora, Paco de Lucía
- Smart recommendations using tag overlap (content-based filtering)
- Add/remove likes, live-updating scores
- Quick-play buttons (opens searches in a new tab)
- Private by default — all data stays in your browser
- Export your liked artists as JSON

## How to Use
1. Open `index.html` in any modern browser.
2. Add more artists via the search box.
3. Click **+ Like** on recommendations to refine the results.
4. Use **Export** to download your list as a JSON file.

## Notes
- The catalog is a lightweight hand-curated list with genre tags (see `data.js`). You can expand it any time.
- This app does not stream audio directly; it links to search results on YouTube and Spotify for simplicity and compatibility.
