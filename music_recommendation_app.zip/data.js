// Lightweight catalog with tags for recommendation
// Tags: classic_rock, rock, blues, jazz, soul, vocal_jazz, fusion, bop, piano, guitar, singer_songwriter,
// world, flamenco, morna, fado, tango, balkan, latin, afrobeat, mediterranean, folk, funk, rnb

const CATALOG = [
  // --- User seeds ---
  { name: "Genesis", tags: ["classic_rock","rock","progressive","british"], country:"UK" },
  { name: "The Beatles", tags: ["classic_rock","rock","british","singer_songwriter","pop"], country:"UK" },
  { name: "The Rolling Stones", tags: ["classic_rock","rock","british","blues"], country:"UK" },
  { name: "Eric Clapton", tags: ["classic_rock","rock","british","blues","guitar"], country:"UK" },
  { name: "Nina Simone", tags: ["jazz","soul","vocal_jazz","piano","civil_rights"], country:"US" },
  { name: "Goran Project", tags: ["world","balkan","mediterranean"], country:"BA" },
  { name: "Cesária Évora", tags: ["world","morna","lusophone"], country:"CV" },
  { name: "Paco de Lucía", tags: ["world","flamenco","guitar","spanish"], country:"ES" },

  // --- Classic Rock Circle ---
  { name: "Led Zeppelin", tags: ["classic_rock","rock","british","blues","guitar"] },
  { name: "Pink Floyd", tags: ["classic_rock","rock","progressive","british"] },
  { name: "The Who", tags: ["classic_rock","rock","british"] },
  { name: "Queen", tags: ["classic_rock","rock","british"] },
  { name: "Jimi Hendrix", tags: ["rock","guitar","psychedelic","blues"] },
  { name: "Cream", tags: ["classic_rock","blues","british","guitar"] },
  { name: "Dire Straits", tags: ["classic_rock","rock","guitar","british"] },
  { name: "Fleetwood Mac", tags: ["rock","classic_rock","singer_songwriter"] },
  { name: "The Eagles", tags: ["classic_rock","rock","american","singer_songwriter"] },
  { name: "Santana", tags: ["rock","latin","guitar","fusion"] },
  { name: "The Doors", tags: ["rock","psychedelic","classic_rock"] },
  { name: "Tom Petty", tags: ["rock","american","singer_songwriter"] },

  // --- Blues & Guitar ---
  { name: "B.B. King", tags: ["blues","guitar","american"] },
  { name: "Buddy Guy", tags: ["blues","guitar","american"] },
  { name: "John Lee Hooker", tags: ["blues","american"] },
  { name: "Robert Johnson", tags: ["blues","american","delta"] },
  { name: "Gary Moore", tags: ["blues","rock","guitar"] },
  { name: "Mark Knopfler", tags: ["rock","guitar","singer_songwriter"] },

  // --- Jazz Core ---
  { name: "Miles Davis", tags: ["jazz","trumpet","fusion","bop"] },
  { name: "John Coltrane", tags: ["jazz","saxophone","bop"] },
  { name: "Bill Evans", tags: ["jazz","piano","bop"] },
  { name: "Herbie Hancock", tags: ["jazz","piano","fusion","funk"] },
  { name: "Charles Mingus", tags: ["jazz","bass","bop"] },
  { name: "Ella Fitzgerald", tags: ["jazz","vocal_jazz","swing"] },
  { name: "Sarah Vaughan", tags: ["jazz","vocal_jazz","swing"] },
  { name: "Chet Baker", tags: ["jazz","trumpet","cool_jazz"] },
  { name: "Norah Jones", tags: ["jazz","singer_songwriter","piano","vocal_jazz"] },

  // --- World / Roots ---
  { name: "Goran Bregović", tags: ["world","balkan","brass","soundtrack"] },
  { name: "Buena Vista Social Club", tags: ["world","latin","cuba","son","bolero"] },
  { name: "Omara Portuondo", tags: ["world","latin","cuba","bolero"] },
  { name: "Manu Chao", tags: ["world","latin","mediterranean","folk"] },
  { name: "Gotan Project", tags: ["world","tango","electronic"] },
  { name: "Amália Rodrigues", tags: ["world","fado","lusophone"] },
  { name: "Mariza", tags: ["world","fado","lusophone"] },
  { name: "Gipsy Kings", tags: ["world","flamenco","rumba","guitar"] },
  { name: "Tinariwen", tags: ["world","desert_blues","africa"] },
  { name: "Anouar Brahem", tags: ["world","mediterranean","oud","jazz"] },
  { name: "Ali Farka Touré", tags: ["world","desert_blues","africa","guitar"] },

  // --- Crossover / Instrumental ---
  { name: "Pat Metheny", tags: ["jazz","fusion","guitar"] },
  { name: "Al Di Meola", tags: ["jazz","fusion","guitar","flamenco"] },
  { name: "Rodrigo y Gabriela", tags: ["world","flamenco","guitar","instrumental"] },
  { name: "Sting", tags: ["rock","pop","singer_songwriter","world"] },
  { name: "Peter Gabriel", tags: ["rock","world","british","singer_songwriter"] },
  { name: "Paul Simon", tags: ["rock","world","singer_songwriter"] },

  // --- More Classic / Alt ---
  { name: "The Kinks", tags: ["classic_rock","rock","british"] },
  { name: "Jeff Beck", tags: ["rock","guitar","fusion"] },
  { name: "Yes", tags: ["rock","progressive","british"] },
  { name: "King Crimson", tags: ["rock","progressive","british"] },
  { name: "Bob Dylan", tags: ["singer_songwriter","folk","rock"] },
  { name: "Leonard Cohen", tags: ["singer_songwriter","folk"] },
  { name: "Nick Drake", tags: ["singer_songwriter","folk"] },
  { name: "Van Morrison", tags: ["rock","soul","singer_songwriter"] }
];
