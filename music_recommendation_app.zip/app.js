// Simple tag-overlap recommender (content-based)
const SEED_LIKES = new Set([
  "Genesis","The Beatles","The Rolling Stones","Eric Clapton","Nina Simone",
  "Goran Project","Cesária Évora","Paco de Lucía"
]);

function tagScore(artist, likeTags) {
  // Jaccard-like overlap
  const a = new Set(artist.tags);
  let inter = 0;
  likeTags.forEach(t => { if (a.has(t)) inter++; });
  const union = new Set([...a, ...likeTags]).size;
  return union === 0 ? 0 : inter / union;
}

function computeRecommendations(likes) {
  const likedSet = new Set(likes.map(x => x.name));
  const likeTags = new Set(likes.flatMap(x => x.tags));
  const scored = CATALOG
    .filter(a => !likedSet.has(a.name))
    .map(a => ({...a, score: tagScore(a, likeTags)}))
    .filter(x => x.score > 0)
    .sort((a,b) => b.score - a.score)
    .slice(0, 30);
  return scored;
}

function renderLikes(likes) {
  const el = document.getElementById('likes');
  el.innerHTML = '';
  likes.forEach(a => {
    const div = document.createElement('div');
    div.className = 'pill';
    div.innerHTML = `<span>${a.name}</span>`;
    const rm = document.createElement('button');
    rm.textContent = '−';
    rm.title = 'Remove from likes';
    rm.addEventListener('click', () => {
      state.likes = state.likes.filter(x => x.name !== a.name);
      update();
    });
    div.appendChild(rm);
    el.appendChild(div);
  });
}

function renderRecs(recs) {
  const el = document.getElementById('recoList');
  el.innerHTML = '';
  recs.forEach(a => {
    const card = document.createElement('div');
    card.className = 'card';
    const tags = a.tags.slice(0,5).join(', ');
    card.innerHTML = `
      <div class="row"><strong>${a.name}</strong><span class="meta">${a.score.toFixed(2)}</span></div>
      <div class="meta">${tags}</div>
      <div class="row">
        <button class="btn add">+ Like</button>
        <a class="btn" target="_blank" rel="noopener" href="${ytLink(a.name)}">YouTube</a>
        <a class="btn" target="_blank" rel="noopener" href="${spLink(a.name)}">Spotify</a>
      </div>
    `;
    card.querySelector('.add').addEventListener('click', () => {
      if (!state.likes.find(x => x.name === a.name)) {
        state.likes.push(a);
        update();
      }
    });
    el.appendChild(card);
  });
}

function renderQuickPlay(likes) {
  const el = document.getElementById('quickPlay');
  el.innerHTML = '';
  likes.slice(0, 16).forEach(a => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <strong>${a.name}</strong>
      <div class="row">
        <a class="btn" target="_blank" rel="noopener" href="${ytLink(a.name)}">YouTube Top</a>
        <a class="btn" target="_blank" rel="noopener" href="${spLink(a.name)}">Spotify Search</a>
      </div>
    `;
    el.appendChild(card);
  });
}

function ytLink(name) {
  return "https://www.youtube.com/results?search_query=" + encodeURIComponent(name + " top tracks");
}
function spLink(name) {
  return "https://open.spotify.com/search/" + encodeURIComponent(name);
}

function attachSearch() {
  const input = document.getElementById('artistSearch');
  const box = document.getElementById('suggestions');
  const showSuggestions = (items) => {
    if (!items.length) { box.style.display = 'none'; box.innerHTML = ''; return; }
    box.style.display = 'block';
    box.innerHTML = '';
    items.slice(0,8).forEach(a => {
      const div = document.createElement('div');
      div.className = 'item';
      div.textContent = a.name + ' — ' + (a.tags.slice(0,3).join(', '));
      div.addEventListener('click', () => {
        if (!state.likes.find(x => x.name === a.name)) state.likes.push(a);
        input.value = '';
        box.style.display = 'none';
        update();
      });
      box.appendChild(div);
    });
  };
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase().trim();
    if (!q) { showSuggestions([]); return; }
    const likedNames = new Set(state.likes.map(a => a.name));
    const matches = CATALOG.filter(a => a.name.toLowerCase().includes(q) && !likedNames.has(a.name));
    showSuggestions(matches);
  });
  document.addEventListener('click', (e) => {
    if (!box.contains(e.target) && e.target !== input) box.style.display = 'none';
  });
}

function attachExport() {
  const btn = document.getElementById('exportBtn');
  const link = document.getElementById('exportLink');
  btn.addEventListener('click', () => {
    const payload = {
      liked_artists: state.likes.map(a => ({ name: a.name, tags: a.tags })),
      exported_at: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = 'my-liked-artists.json';
    link.textContent = 'Download ready: my-liked-artists.json';
    link.style.display = 'inline-block';
  });
}

const state = {
  likes: CATALOG.filter(a => Array.from(SEED_LIKES).includes(a.name))
};

function update() {
  renderLikes(state.likes);
  renderRecs(computeRecommendations(state.likes));
  renderQuickPlay(state.likes);
}

window.addEventListener('DOMContentLoaded', () => {
  attachSearch();
  attachExport();
  update();
});
